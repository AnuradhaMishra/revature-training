create table customer(customerId int unique not null, customerName varchar(50) not null, password varchar(16) not null, customerBalance int not null );
select * from customer 

create table employee(employeeId int unique not null, employeeName varchar(50) not null, password varchar(16) not null);
select * from employee 

create table temporarydata(id int not null, name varchar(50) not null, password varchar(16) not null,balance int,type varchar(1) not null);
select  * from temporarydata ;

insert into employee values(1, 'Emp1', 'abcd');

insert into temporarydata values(5, 'Emp1', 'abcd',null,'e');


insert into customer values(12,'Anu', 'www', 1000)

insert into customer values(10,'ABC', 'abc', 1500)

truncate table temporarydata

delete  from customer where customername='DemoCustomer';

drop table employee 





-------------------------------------------customer transfer balance----------------------------------------
create or replace procedure transferamount
(
   sender int,
   receiver int,
   amount dec
)
language  plpgsql
as $$
begin 
		update bankingapp.customer set customerbalance = customerbalance - amount where customerid = sender;
		update bankingapp.customer set customerbalance = customerbalance + amount where customerid = receiver;

commit;
end;$$


call transferamount(10, 12, 100)


select * from customer c 

