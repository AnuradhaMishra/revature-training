package com;

import com.projectzero.bms.App.BankApp;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        BankApp bankApp = new BankApp() ;
        bankApp.startBankingApp();
    }
}
