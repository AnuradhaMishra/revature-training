package com.projectzero.bms.App;

public class KnowApp {
  
  public void appDetails () {
    System.out.println("\t\t\t\t##### A B O U T   T H E   A P P #####\n\n");

    System.out.println("Anuradha Bank of Ghaziabad-It is digital banking application provided by the Anuradha bank of Ghaziabad.") ;
    System.out.println("it is a safe, secure and user friendly digital bank application. in this you can create account and we ") ;
    System.out.println("give services for customer as well as employees.");
    System.out.println("Following features included in this app is:-");
    System.out.println("o Transfer Amount");
    System.out.println("o View Balance");

  }
}