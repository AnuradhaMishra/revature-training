package com.projectzero.bms.App;

public class KnowDev {

  public void devDetails() {
    System.out.println("\t\t\t\t##### A B O U T   M E #####\n\n");
    System.out.println("Hi, my name is Anuradha Mishra. I am currently working as a Software Engineer Trainee at Revature India.");
    System.out.println("I have completed my graduation from HMR Institute of Technology and Management, Delhi in Electronics and");
    System.out.println("Comunication Engineering. My overall CGPA was 7.95. I have always been inclined towards technology and");
    System.out.println("that's why I have knowledge about : ");
    System.out.println("o Java");
    System.out.println("o PostgreSQL");
    System.out.println("o Python");
    System.out.println("o C/C++");
    System.out.println("o Machine Learning");
    System.out.println("o Amazon Web Services");
    System.out.println("\nIn case you want to know more about me and my works, you can reach out to me at : ");
    System.out.println("LinkedIn - https://linkedin.com/in/amanuradhamishra");
    System.out.println("GitHub = https://github.com/AnuradhaMishra");
    System.out.println("\nThank You for checking out my app!!");
  }
}