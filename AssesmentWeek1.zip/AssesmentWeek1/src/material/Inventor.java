package material;

public class Inventor {
	int quantity;
	int lowOrderLevelQuantity;
}
