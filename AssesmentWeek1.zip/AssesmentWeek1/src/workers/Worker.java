package workers;

public class Worker {
	
	String name;
	int salary;
	String type;
	
	
	public void pay() {
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
