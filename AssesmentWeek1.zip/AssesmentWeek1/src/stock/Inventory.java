package stock;

public class Inventory {
	
	int lowOrderLevelQuantity;
	int quantity;
	int uniqueId;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
