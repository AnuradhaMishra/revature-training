
public class PaymentDetail {
	
	public void payDetail1() {
		
		System.out.println("Payment of category A product is -  2000");
	}
	
	
	
public void payDetail2() {
		
		System.out.println("Payment of category B product is -  4000");
	}

}
