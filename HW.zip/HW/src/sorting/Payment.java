package sorting;

public class Payment {
	int paymentId;
	String paymentType;
	int amount;
	String status;
	public Payment(int paymentId, String paymentType, int amount, String status) {
		super();
		this.paymentId = paymentId;
		this.paymentType = paymentType;
		this.amount = amount;
		this.status = status;
	}
	public int getPaymentId() {
		return paymentId;
	}
	public void setPaymentId(int paymentId) {
		this.paymentId = paymentId;
	}
	public String getPaymentType() {
		return paymentType;
	}
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "\n paymentId = " + paymentId + "| paymentType = " + paymentType + "| amount = " + amount + "| status = "
				+ status  ;
	}
	

	
}
