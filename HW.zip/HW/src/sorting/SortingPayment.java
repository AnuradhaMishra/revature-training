package sorting;

import java.util.*;
//import java.util.List;

public class SortingPayment {

	public static void main(String[] args) {
		List<Payment> payment = new ArrayList<Payment>();
		payment.add(new Payment(1, "Cash       ", 19000, "Paid"));
		payment.add(new Payment(2, "UPI        ", 10000, "Pending"));
		payment.add(new Payment(3, "Card       ", 16000, "Paid"));
		payment.add(new Payment(4, "NetBanking ", 88000, "Failed"));
		
		System.out.println("Select Menu\n1. Sort by PaymentId\n2. Sort by PaymentType\n3. Sort by Amount\n4. Sort by Status\n5. Exit");
		int option;
		Scanner sc = new Scanner(System.in);
		option = sc.nextInt();
		
		switch(option) {
		case 1:
			System.out.println("Sort by PaymentId");
			Collections.sort( payment , new Comparator<Payment>(){

				@Override
				public int compare(Payment o1, Payment o2) {
					
					if(o1.getPaymentId()>o2.getPaymentId()) {
						return 1;
					}
					else
						return -1;
				}
				
				
			});
			System.out.println(payment);
			break;
			
		case 2:
			System.out.println("Sort by PaymentType");
			Collections.sort( payment , new Comparator<Payment>(){

				@Override
				public int compare(Payment o1, Payment o2) {
					
					if(o1.getPaymentType().compareTo(o2.getPaymentType())>0) {
						return 1;
					}
					else
						return -1;
				}
				
				
			});
			System.out.println(payment);

			break;
			
		case 3:
			System.out.println("Sort by Amount");
			Collections.sort( payment , new Comparator<Payment>(){

				@Override
				public int compare(Payment o1, Payment o2) {
					
					if(o1.getAmount()>o2.getAmount()) {
						return 1;
					}
					else
						return -1;
				}
				
				
			});
			System.out.println(payment);

			break;
			
		case 4:
			System.out.println("Sort by Status");
			Collections.sort( payment , new Comparator<Payment>(){

				@Override
				public int compare(Payment o1, Payment o2) {
					
					if(o1.getStatus().compareTo(o2.getStatus())>0) {
						return 1;
					}
					else
						return -1;
				}
				
				
			});
			System.out.println(payment);

			break;
			
		case 5:
			break;
			
			
		}
		
		
		
	}

}
