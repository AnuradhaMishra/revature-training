package zoo;

public abstract class Feline extends Animal  {

	

	@Override
	void raom() {
		System.out.println("All feline roams in same way");
		// TODO Auto-generated method stub
		
	}
	

}

class  Lion extends Feline{

	
	
	@Override
	void makenoise() {
		System.out.println("Lion sound is Roar");
		// TODO Auto-generated method stub
		picture = "https://lionalert.org/wp-content/uploads/2020/01/Lion-Family-1024x675.jpg";
		System.out.println("Picture of Lion " +picture);
		
	}

	@Override
	void eat() {
		System.out.println("Lion eats Flesh");
		// TODO Auto-generated method stub
		
	}

}

class  Tiger extends Feline{

	
	
	@Override
	void makenoise() {
		System.out.println("Tiger sound is Chuff");
		// TODO Auto-generated method stub
		picture = "https://c402277.ssl.cf1.rackcdn.com/photos/18134/images/hero_small/Medium_WW226365.jpg?1574452099";
		System.out.println("Picture of Tiger " +picture);
		
	}

	@Override
	void eat() {
		System.out.println("Tiger eats Flesh");
		// TODO Auto-generated method stub
		
	}

}

class  Cat extends Feline{

	
	
	@Override
	void makenoise() {
		System.out.println("Cat sound is Meow");
		// TODO Auto-generated method stub
		picture = "https://cdn.britannica.com/s:800x1000/22/206222-050-3F741817/Domestic-feline-tabby-cat.jpg";
		System.out.println("Picture of Cat " +picture);
		
	}

	@Override
	void eat() {
		System.out.println("Cat eats Rat");
		// TODO Auto-generated method stub
		
	}

}

