package zoo;

public class Zoo {

	public static void main(String[] args) {
		
		Animal a = new Lion();
		a.eat();
		a.makenoise();
		a.raom();
		a.sleep();
		a = new Tiger();
		a.eat();
		a.makenoise();
		a.raom();
		a.sleep();
		a = new Cat();
		a.eat();
		a.makenoise();
		a.raom();
		a.sleep();
		a = new Hippo();
		a.eat();
		a.makenoise();
		a.raom();
		a.sleep();
		a = new Dog();
		a.eat();
		a.makenoise();
		a.raom();
		a.sleep();
		a = new Wolf();
		a.eat();
		a.makenoise();
		a.raom();
		a.sleep();
		
		// TODO Auto-generated method stub

	}

}
