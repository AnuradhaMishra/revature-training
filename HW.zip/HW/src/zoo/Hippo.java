package zoo;

public class Hippo extends Animal {

	@Override
	void makenoise() {
		System.out.println("Hippo sound is Grunt");
		// TODO Auto-generated method stub
		picture = "https://www.pitara.com/media/hippopotamus-river-horse_hub68f7c15ce6bcc55078f9ed65b7a2f49_130703_600x0_resize_q60_box.jpg";
		System.out.println("Picture of Hippo " +picture);
		
		
	}

	@Override
	void eat() {
		System.out.println("Hippo eats Grass");
		// TODO Auto-generated method stub
		
	}

	@Override
	void raom() {
		// TODO Auto-generated method stub
		
	}
	

}
