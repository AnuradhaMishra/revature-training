package zoo;

public abstract class  Canine extends Animal{

	
	@Override
	void raom() {
		System.out.println("All canine roams in same way");
		// TODO Auto-generated method stub
		
	}

}


  class  Dog extends Canine{

	
	
	@Override
	void makenoise() {
		System.out.println("Dog sound is Woof");
		// TODO Auto-generated method stub
		picture = "https://i.insider.com/5484d9d1eab8ea3017b17e29?width=1000&format=jpeg&auto=webp";
		System.out.println("Picture of Dog " +picture);
		
		
	}

	@Override
	void eat() {
		System.out.println("Dog eats Pedigree");
		// TODO Auto-generated method stub
		
	}

}
  
  
  class  Wolf extends Canine{

		
		
		@Override
		void makenoise() {
			System.out.println("Wolf sound is Howl");
			// TODO Auto-generated method stub
			picture = "https://upload.wikimedia.org/wikipedia/commons/thumb/5/5f/Kolm%C3%A5rden_Wolf.jpg/220px-Kolm%C3%A5rden_Wolf.jpg";
			System.out.println("Picture of Wolf " +picture);
			
			
		}

		@Override
		void eat() {
			System.out.println("Wolf eats Flesh");
			// TODO Auto-generated method stub
			
		}

	}


