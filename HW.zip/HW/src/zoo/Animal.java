package zoo;

public abstract class Animal {
	String picture ;
	
	abstract void makenoise();
	abstract void eat();
	abstract void raom();
	public void sleep() {
		System.out.println("All animal sleeping in same way\n");
	}


	

}


