
public class OrderDetail {
	
	public void ord1() {
		
		System.out.println("OrderDetail of product category A is - Shipped on 21 july");
	}
	
	 
	public void ord2() {
		
		System.out.println("OrderDetail of product category B is - Shipped on 22 july");
	}

}
