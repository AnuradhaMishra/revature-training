package control;

import java.util.Scanner;

public class Add5Number {
	
	

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int[] num = new int[5];
		for (int i = 0; i < num.length; i++) {
			//System.out.println("Please enter number -  : "+ (i+1));
			
			num[i] = sc.nextInt();
		}
		int sum =0;
		
		for(int temp:num) {
			sum = temp+sum;
		}
			System.out.println(sum);
			
		
		
		

		// TODO Auto-generated method stub

	}

}
