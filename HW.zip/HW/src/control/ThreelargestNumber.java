package control;
import java.util.*;

public class ThreelargestNumber {
	
	public static void main(String[] args) {
		int num1;
		int num2;
		int num3;
		System.out.println("enter the 1st number- ");
		Scanner sc = new Scanner(System.in);
		num1  = sc.nextInt();
		System.out.println("enter the 2st number- ");
		Scanner sc1 = new Scanner(System.in);
		num2  = sc1.nextInt();
		System.out.println("enter the 3st number- ");
		Scanner sc2 = new Scanner(System.in);
		num3  = sc2.nextInt();
			
		
		if(num1>num2&&num1>num3) {
			System.out.println(num1);
		}
		
		
		else {
			if(num2>num1&&num2>num3) {
			System.out.println(num2);
		}
			else {
				System.out.println(num3);
			}
		
		
		// TODO Auto-generated method stub

	}

}
}
