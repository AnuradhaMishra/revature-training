package control;
import java.util.Scanner;

public class DobS {
	
	int date;
	int month;
	int year;
	
public void display() {
	
	Scanner sc = new Scanner(System.in);
	
	System.out.println("Enter Date-:");
	date = sc.nextInt();
	System.out.println("Enter Month-:");
	month = sc.nextInt();


	System.out.println("Enter Year-:");
	year = sc.nextInt();
	
	
int x =0;
if(year>=1990&& year<=1995)
	x = 1;
else if(year>=1996&& year<2000)
	x = 2;
else if(year>=2000&& year<=2010)
	x =3;
else if(year>=2011&& year<=2021)
	x = 4;


	
	
	
	switch (x) {
	
	case 1:
		System.out.println("You are early 90's bron.");
		break;
	case 2:
		System.out.println("You are late 90's born");
		break;
	case 3:
		System.out.println("You are new decade born.");
		break;
	case 4:
		System.out.println("You are recently born.");
		break;
		default:
			System.out.println("Invalid Year-");
			break;
		
		}
	//return ans;
	
	
}	
	
	
	
	
	
	
	
	

	public static void main(String[] args) {
		
		
		DobS d = new DobS();
		d.display();
		// TODO Auto-generated method stub

	}
	

}
