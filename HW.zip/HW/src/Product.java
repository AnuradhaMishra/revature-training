
public class Product {
	
public void prod1() {
		
		System.out.println("This product is in category A");
	}




public void prod2() {
	
	System.out.println("This product is in category B");
}
}