package calculator;

public class InputMisMatchException  extends RuntimeException{
	
	public InputMisMatchException() {
		// TODO Auto-generated constructor stub
	}
	public  InputMisMatchException(String msg) {
		
		super(msg);
	}

}
