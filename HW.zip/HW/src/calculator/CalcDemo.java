package calculator;

import java.util.Scanner;

//import testdemo.InvalidAmountException;

public class CalcDemo {
	
//	int number1;
//	int number2;
//	int number3;
	public void display() throws InputMisMatchException {
		int number1;
		int number2;
		int number3 ;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Number1");
		number1 = sc.nextInt();
		System.out.println("Enter the Number2");
		number2 = sc.nextInt();
		System.out.println("Choose the number(#1-addtition,#2-Subtraction,#3 - Multiplication,#4 -Division#)");
		number3 = sc.nextInt();
		
		if(number3>4||number3<1) {
			throw new InputMisMatchException("You have chosen Wrong Number");
		}
			
		
		else {
			switch(number3) {
			case 1:
				System.out.println("Addtion of two number is :-"+(number1+number2));
				break;
			case 2:
				System.out.println("Subtraction of two number is :-"+(number1-number2));
				break;
			case 3:
				System.out.println("Multiplication of two number is :-"+(number1*number2));
				break;
			case 4:
				try {
					System.out.println("Division of two number is :-" + (number1 / number2));
					break;
				} catch (ArithmeticException e) {
					System.out.println("Can not divide by zero");
					break;
					// TODO: handle exception
				}
			default:
				System.out.println("Invalid number");
			break;
				
				
			
				
				
				
				
				
			
			
			
			
			
			}
			
			
		}
		
		
		

		
	}
	
	
		
	
	
	
	

	public static void main(String[] args) {
		CalcDemo a = new CalcDemo();
		a.display();
		
		// TODO Auto-generated method stub

	}

}
