
public class Welcome {

	public static void main(String[] args) {
		
		
		Product a = new Product();
		a.prod1();
		OrderDetail b = new OrderDetail();
		b.ord1();
		StockDetail c = new StockDetail();
		c.stD1();
		PaymentDetail d = new PaymentDetail();
		d.payDetail1();
		
		
		//Product a = new Product();
		a.prod2();
		//OrderDetail b = new OrderDetail();
		b.ord2();
		//StockDetail c = new StockDetail();
		c.stD2();
		//PaymentDetail d = new PaymentDetail();
		d.payDetail2();
		
		
		// TODO Auto-generated method stub

	}

}
