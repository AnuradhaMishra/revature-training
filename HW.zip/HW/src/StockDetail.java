
public class StockDetail {
	
	public void stD1() {
		System.out.println("stockdetail of product A  is - 2 pieces of dress ");
	}

	
	
	public void stD2() {
		System.out.println("stockdetail of product B  is - 4 pieces of dress ");
	}
}
