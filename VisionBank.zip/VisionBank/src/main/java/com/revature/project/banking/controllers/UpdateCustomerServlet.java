package com.revature.project.banking.controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.revature.project.banking.model.Customer;
import com.revature.project.banking.service.CustomerService;
import com.revature.project.banking.service.CustomerServiceImpl;

/**
 * Servlet implementation class UpdateCustomerServlet
 */
public class UpdateCustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UpdateCustomerServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");
		String emailId = request.getParameter("emailId");
		String mobileNumber = request.getParameter("mobileNumber");
		String city = request.getParameter("city");
		String accountType = request.getParameter("accountType");
		HttpSession session = request.getSession();
		int customerId = (int)session.getAttribute("customerId");

		Customer customer = new Customer();
		customer.setCustomerId(customerId);
		customer.setFirstName(firstName);
		customer.setLastName(lastName);
		customer.setEmailId(emailId);
		customer.setMobileNumber(mobileNumber);
		customer.setCity(city);
		customer.setAccountType(accountType);

		CustomerService customerService = new CustomerServiceImpl();
		boolean result = customerService.updateCustomer(customer);

		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		if (result) {
			out.write("<!DOCTYPE html>\r\n"
					+ "<html>\r\n"
					+ "<head>\r\n"
					+ "<meta charset=\"ISO-8859-1\">\r\n"
					+ "<link rel=\"shortcut icon\" type=\"image/x-icon\" href=\"images/logo-short.png\" />\r\n"
					+ "<title>Success - Banking Project</title>\r\n"
					+ "<link type=\"text/css\" rel=\"stylesheet\" href=\"css/style.css\" />\r\n"
					+ "<script type=\"text/javascript\" src=\"js/loginvalidator.js\"></script>\r\n"
					+ "\r\n"
					+ "\r\n"
					+ "</head>\r\n"
					+ "<body>\r\n"
					+ "	<h1>\r\n"
					+ "		<center>Vision Bank of India\r\n"
					+ "		<img  alt=\"Vision Bank Of India\" src=\"images/logo-long.png\" style = \"float:left;\"  width=\"300\"/>\r\n"
					+ "	</h1>\r\n"
					+ "	<nav class=\"navigation-bar\">\r\n"
					+ "		&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<a href=\"Home.html\" class=\"navtext\">Home</a>&emsp;&emsp;<a href=\"login.html\" class=\"navtext\">Login</a>&emsp;&emsp;<a href=\"apply.html\" class=\"navtext\">Apply</a>&emsp;&emsp;<a href=\"aboutApp.html\" class=\"navtext\">AboutApp</a>&emsp;&emsp;<a href=\"aboutdev.html\" class=\"navtext\">AboutMe</a>\r\n"
					+ "\r\n"
					+ "\r\n"
					+ "	</nav>\r\n");

			out.write("<br><br>");
			out.write("<h2 align=\"center\">Customer Update Successful</h2>");
			out.write("<br><br>");
			out.write("<h5 class=\"userpassword\">Customer Details updated for customer Id: " + customerId + " successfully</h5>");

			out.write(
					"<br><br><span class=\"signoutfeedback\"><a class = \"buttons\" href = \"ViewBalanceServlet\">VIEW BALANCE</a><a class = \"buttons\" href = \"Home.html\">HOME</a></span>");

			out.write("<br><br><br><br><br><br><br><br><br><br><br><br>");
			out.write("</body>\r\n"
					+ "<footer class=\"footcopy\" align=\"center\">&copy; 2021, Vision Bank of India | All Rights Reserved.</footer>\r\n"
					+ "\r\n"
					+ "</html>");
		}
		else {
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("ErrorHandlerServlets");
			requestDispatcher.forward(request, response);
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

}
