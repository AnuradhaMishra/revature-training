package com.revature.training.spring_first_app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.revature.training.spring_first_app.model.Employee;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	
    	ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
    	//Employee employee = (Employee)context.getBean("e2");
    	Employee employee1 = (Employee)context.getBean("e");

        //System.out.println( employee );
        System.out.println( employee1 );

    }
}
