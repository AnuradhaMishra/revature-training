package com.revature.training.spring_first_app.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.revature.training.spring_first_app.model.Email;
import com.revature.training.spring_first_app.model.Employee;

@Configuration
public class AppConfig {
	@Bean(name="e")
	public Employee getEmployee() {
		return new Employee();
	}
	@Bean(name="email")
	public Email getEmail() {
		return new Email("aa@b.com","xyz@gmail.com","hlo","howwwww");
	}
	
	@Bean(name="en")
	public String getEmployeeName() {
		return new String("VishnuGupta");
	}

}
