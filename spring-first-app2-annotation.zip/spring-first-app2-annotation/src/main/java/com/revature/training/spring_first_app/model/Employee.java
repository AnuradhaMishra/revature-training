package com.revature.training.spring_first_app.model;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Employee {
	private int employeeId;
	@Autowired
	@Qualifier("en")

	private String employeeName;
	private String address;
	private int salary;
	//dependency object
	@Autowired(required=false)
	@Qualifier("email")
	private Email email;
	
	
	public Employee() {
		
	}


	public Employee(int employeeId, String employeeName, String address, int salary,Email email) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.address = address;
		this.salary = salary;
		this.email =email;
	}
	
	//init method
	@PostConstruct
	public void rev1() {
		System.out.println("called rev function");
		
	}
	@PostConstruct
	public void display() {
		System.out.println("it called***");
	}
	
	


	public Employee(int employeeId, String employeeName) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
	}


	public int getEmployeeId() {
		return employeeId;
	}


	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}


	public String getEmployeeName() {
		return employeeName;
	}


	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public int getSalary() {
		return salary;
	}


	public void setSalary(int salary) {
		this.salary = salary;
	}
	


	public Email getEmail() {
		return email;
	}


	public void setEmail(Email email) {
		this.email = email;
	}


	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", address=" + address
				+ ", salary=" + salary + ", email=" + email + "]";
	}


	
	

}
