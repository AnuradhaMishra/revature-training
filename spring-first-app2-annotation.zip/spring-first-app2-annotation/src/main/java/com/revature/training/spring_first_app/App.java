package com.revature.training.spring_first_app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.revature.training.spring_first_app.config.AppConfig;
import com.revature.training.spring_first_app.model.Email;
import com.revature.training.spring_first_app.model.Employee;

/**
 * Hello world!s
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	
    	ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
    	//Employee employee = (Employee)context.getBean("e2");
    	
    	Email email =(Email)context.getBean("email");
    	//email.setTo("abc@gmail.com");
    	Employee employee1 = (Employee)context.getBean("e");
    	//employee1.setEmail(email);
    	employee1.setEmployeeId(1);
    	employee1.setSalary(230000);

        //System.out.println( employee );
        System.out.println( employee1 );

    }
}
